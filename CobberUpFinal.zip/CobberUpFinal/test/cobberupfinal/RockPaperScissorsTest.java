
package cobberupfinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/* @author S(H)ARK TANK  KINSEY */
public class RockPaperScissorsTest {
    
    public RockPaperScissorsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of SetScene method, of class RockPaperScissors.
     */
    @Test
    public void testSetScene() {
        System.out.println("SetScene");
        RockPaperScissors instance = new RockPaperScissors();
        instance.SetScene();
    }

    /**
     * Test of ComputerPick method, of class RockPaperScissors.
     * Chooses random value out of 3, cannot be truly tested. 
     */
    @Test
    public void testComputerPick() {
        System.out.println("ComputerPick");
        RockPaperScissors instance = new RockPaperScissors();
        int random = 1;
        assertTrue("Error, random is out of bounds" , random <=3 && random >=0);
        int result = instance.ComputerPick();
        assertEquals(random, result);
    }

   /**
     * Test of GameRules method, of class RockPaperScissors.
     */
    @Test
    public void testGameRules_checkIfstaatmestEqualone_retunsOneValue() {
        System.out.println("GameRules");
        RockPaperScissors instance = new RockPaperScissors();
        instance.GameRules();
        int ComputerPick = 1;
        int expResult = 1;
        assertEquals(ComputerPick, expResult);
    }
    
    @Test
    public void testGameRules_checkIfstaatmestEqualzero_retunsZeroValue() {
        System.out.println("GameRules");
        RockPaperScissors instance = new RockPaperScissors();
        instance.GameRules();
        int ComputerPick = 0;
        int expResult = 0;
        assertEquals(ComputerPick, expResult);
    }
    
    @Test
    public void testGameRules_checkIfstaatmestEqualtwo_retunsTwoValue() {
        System.out.println("GameRules");
        RockPaperScissors instance = new RockPaperScissors();
        instance.GameRules();
        int ComputerPick = 2;
        int expResult = 2;
        assertEquals(ComputerPick, expResult);
    }

    /**
     * Test of GameWin method, of class RockPaperScissors.
     */
    @Test
    public void testGameWin() {
        System.out.println("GameWin");
        RockPaperScissors instance = new RockPaperScissors();
        instance.GameWin();
        int result = 3;
        int expected = 3;
        assertEquals( result , expected);
    }

    /**
     * Test of PlayGame method, of class RockPaperScissors.
     */
    @Test
    public void testPlayGame() {
        System.out.println("PlayGame");
        RockPaperScissors instance = new RockPaperScissors();
        instance.PlayGame();
    }
    
}