
package cobberupfinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/* @author S(H)ARK TANK SHRISTI */
public class BoardTest {
   
    public BoardTest() {
    }
   
    @BeforeClass
    public static void setUpClass() {
    }
   
    @AfterClass
    public static void tearDownClass() {
    }
   
    @Before
    public void setUp() {
    }
   
    @After
    public void tearDown() {
    }



    /**
     * Test of endgame method, of class Board.
     */
    @Test
    public void testEndgame_false_false() {
        System.out.println("endgame");
        Board instance = new Board();
        boolean expResult = false;
        boolean result = instance.endgame();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    /**
     * Test of GameWin method, of class Board.
     */
    @Test
    public void testGameWin() {
        System.out.println("GameWin");
       
        Board instance = new Board();
        instance.GameWin();
        int result=Scene.GetGameScore();
        assertEquals(7, result);

    }
   
}