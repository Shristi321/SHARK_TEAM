
package cobberupfinal;

import java.awt.AWTException;
import java.awt.event.KeyEvent;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/* @author S(H)ARK TANK SHRISTI */
public class PacListenerTest {
   
    public PacListenerTest() {
    }
   
    @BeforeClass
    public static void setUpClass() {
    }
   
    @AfterClass
    public static void tearDownClass() {
    }
   
    @Before
    public void setUp() {
    }
   
    @After
    public void tearDown() {
    }


 
    /**
     * Test of keyPressed method, of class PacListener.
     */
    @Test
    public void testMoveLeft() throws AWTException {
        System.out.println("keyPressed");
        Board model= new Board();
       
        PacListener instance = new PacListener(new PacMan(model),model);
        int code= KeyEvent.VK_LEFT;
         System.out.println(instance.man.pacx);
      instance.moveLeft(code);
   
         assertEquals(17,instance.man.pacx);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
       
       
    }
 

   
}