
package cobberupfinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/* @author S(H)ARK TANK  RITA */
public class PoppingCobTest {
    
    public PoppingCobTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    /**
     * Test of GetEventButtonX method, of class PoppingCob.
     */
    @Test
    public void testGetEventButtonX() {
        System.out.println("GetEventButtonX");
        PoppingCob instance = new PoppingCob();
        int expResult = 0;
        int result = instance.GetEventButtonX();
        assertEquals(expResult, result);

    }

    /**
     * Test of GetEventButtonY method, of class PoppingCob.
     */
    @Test
    public void testGetEventButtonY() {
        System.out.println("GetEventButtonY");
        PoppingCob instance = new PoppingCob();
        int expResult = 0;
        int result = instance.GetEventButtonY();
        assertEquals(expResult, result);

    }
    /**
     * Test of ChangeAllColors method, of class PoppingCob.
     */
    @Test
    public void testChangeAllColors() {
        System.out.println("ChangeAllColors");
        int Red = 0;
        int Green = 0;
        int Blue = 0;
        PoppingCob instance = new PoppingCob();
        instance.ChangeAllColors(Red, Green, Blue);
        assertEquals(0, Red);
        assertEquals(0, Blue);
        assertEquals(0, Green);
            }

    /**
     * Test of GameWin method, of class PoppingCob.
     */
    @Test
    public void testGameWin() {
        System.out.println("GameWin");
        PoppingCob instance = new PoppingCob();
        instance.GameWin();
        
        int result=Scene.GetGameScore();
        assertEquals(5, result);
    } 



   
    
}
