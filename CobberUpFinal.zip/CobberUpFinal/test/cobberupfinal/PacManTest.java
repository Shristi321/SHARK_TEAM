
package cobberupfinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/* @author S(H)ARK TANK  SHRISTI */
public class PacManTest {
   
    public PacManTest() {
    }
   
    @BeforeClass
    public static void setUpClass() {
    }
   
    @AfterClass
    public static void tearDownClass() {
    }
   
    @Before
    public void setUp() {
    }
   
    @After
    public void tearDown() {
    }
   
    /**
     * Test of strike method, of class PacMan.
     */
    @Test
    public void testStrikeo_Score() {
        System.out.println("strike");
       int c=10;
        PacMan instance = new PacMan(new Board());
        int result=instance.score;
        instance.strikeo(c);
        assertEquals(result,c);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
   
   
}