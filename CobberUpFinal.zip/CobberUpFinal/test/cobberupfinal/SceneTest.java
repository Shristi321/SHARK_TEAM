
package cobberupfinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/* @author S(H)ARK TANK  SHRISTI */
public class SceneTest {
   
    public SceneTest() {
    }
   
    @BeforeClass
    public static void setUpClass() {
    }
   
    @AfterClass
    public static void tearDownClass() {
    }
   
    @Before
    public void setUp() {
    }
   
    @After
    public void tearDown() {
    }

 

    /**
     * Test of GameWin method, of class Scene.
     */
    @Test
    public void testGameWin() {
        System.out.println("GameWin");
        Scene instance = new Scene();
        instance.GameWin();
        

    }

    /**
     * Test of GetGameScore method, of class Scene.
     */
    @Test
    public void testGetGameScore() {
        System.out.println("GetGameScore");
        int expResult = 0;
        int result = Scene.GetGameScore();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of PlayGame method, of class Scene.
     */
    @Test
    public void testPlayGame() {
        System.out.println("PlayGame");
        Scene instance = new Scene();
        instance.PlayGame();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
   
}
