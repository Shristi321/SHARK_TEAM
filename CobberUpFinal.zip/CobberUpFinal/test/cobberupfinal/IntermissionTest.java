
package cobberupfinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/* @author S(H)ARK TANK RITA */
public class IntermissionTest {
    
    public IntermissionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    /**
     * Test of GetNextScreenButtonX method, of class Intermission.
     */
    @Test
    public void testGetNextScreenButtonX() {
        System.out.println("GetNextScreenButtonX");
        Intermission instance = new Intermission();
        int expResult = 0;
        int result = instance.GetNextScreenButtonX();
        assertEquals(expResult, result);

    }

    /**
     * Test of GetNextSecreenButtonY method, of class Intermission.
     */
    @Test
    public void testGetNextSecreenButtonY() {
        System.out.println("GetNextSecreenButtonY");
        Intermission instance = new Intermission();
        int expResult = 0;
        int result = instance.GetNextSecreenButtonY();
        assertEquals(expResult, result);
    }

    /**
     * Test of GameWin method, of class Intermission.
     */
    @Test
    public void testGameWin() {
        System.out.println("GameWin");
        int val = 6;
        Intermission instance = new Intermission();
        instance.GameWin(val);
        int result=Scene.GetGameScore();
        assertEquals(6, result);
    }


    
}
