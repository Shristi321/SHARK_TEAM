package cobberupfinal;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;
/* @author S(H)ARK TANK  SHRISTI */

public class PacMan extends JPanel{
    // ------------------------------------------------------------------------
    //  CREATE instance variables for pac man game
    // ------------------------------------------------------------------------
    public Board model;
    private final Font PacmanFont = new Font("Algerian", Font.BOLD, 16);
    
    int foodCount =0;
    int pacx = 17;
    int pacy = 8;
    int startangle = 30;
    int arcAngle = 300;
    public int blockSize=20;
    int score=10;
    PacListener listen;
    
     //Pac Man Cosntructor
     public PacMan(Board model) {
         this.model=model;
         setSize(blockSize*36,blockSize*22);
     }
         
    // ------------------------------------------------------------------------
    //  Paint the board using Graphics component. 
    // ------------------------------------------------------------------------
    @Override
    public void paint(Graphics g) {
        try{
            g.setColor(Color.black);
            g.fillRect(0, 0, 36*blockSize, 22*blockSize);
            for(int i=0;i<model.board.length;i++){
                for(int j=0;j<model.board[0].length;j++){
                    int c=model.board[i][j];
                    switch (c) {
                        case 1 : g.setColor(Color.red);
                        g.fillRect(i*blockSize, j*blockSize,blockSize,blockSize);
                        break;
                        case 2 : g.setColor(Color.yellow);
                        g.fillOval(i*blockSize+blockSize/4, j*blockSize+blockSize/4, blockSize/4, blockSize/4); 
                        break;
                        case 6 : g.setColor(Color.black);
                        g.fillRect(i*blockSize, j*blockSize,blockSize,blockSize);
                        break;
                        case 8 : g.setColor(Color.yellow);
                        g.fillOval(i*blockSize+blockSize/8, j*blockSize+blockSize/8, blockSize/2, blockSize/2); 
                        break;
                    }
                }
            }
            g.setFont(PacmanFont);
            g.setColor(Color.yellow);
            g.fillArc(pacx*blockSize,pacy*blockSize, blockSize,blockSize, startangle, arcAngle);
            strike(pacx,pacy,g);
            String string = "Score: " + score ;
            g.drawString(string, (int) (getWidth()/2), 20);
        }
        catch(ArrayIndexOutOfBoundsException exception){
            System.out.println("The index used is out of the bounds.");
        }
    }
   
    // ------------------------------------------------------------------------
    //  Score methods
    // ------------------------------------------------------------------------
    
    // Calls Strikeo
    public void strike (int pacx, int pacy, Graphics g) {
        int c= model.board[pacx][pacy];
        strikeo(c);
    }
    // Updates score and board once food is consumed. 
    public void strikeo(int c){
        if(c==2){
            score+=10;
            model.board[pacx][pacy]=6;
            foodCount--;
    }
     if(c==8){
         score+=50;
         model.board[pacx][pacy]=6;
         foodCount--;
     }
    }
}