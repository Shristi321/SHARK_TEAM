
package cobberupfinal;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
    // ------------------------------------------------------------------------
    //  CREATE the main JFrame window to house the game and include inital states
    // ------------------------------------------------------------------------

public class Intermission extends Scene {
    JFrame FirstFrame = new JFrame("Cobber Up");
    JPanel FirstPanel = new JPanel();
    JLabel StoryLine = new JLabel();
    JButton NextScreenButton = new JButton("Next Screen");
    JCheckBox NextScreenCheckBox = new JCheckBox("Are you sure you want to move on? Danger awaits! >:O");
    
    // Override the Scene Classes' set scene method to set this scene. 
    @Override
    public void SetScene(){
        FirstFrame.add(FirstPanel);
        FirstFrame.setSize(900, 600);
        FirstFrame.setVisible(true);
        FirstFrame.setResizable(false);
        FirstFrame.setLayout(null);
        FirstFrame.setLocationRelativeTo(null);
        FirstFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FirstFrame.setLayout(null);
        
        FirstPanel.setBackground(Color.BLACK);
        FirstPanel.setLayout(null);
        FirstPanel.add(NextScreenButton);
        FirstPanel.add(NextScreenCheckBox);
        FirstPanel.add(StoryLine);
        
        NextScreenButton.setBounds(300, 500, 200, 50);
        NextScreenButton.setBackground(Color.yellow);
        NextScreenCheckBox.setVisible(true);
        NextScreenCheckBox.setBackground(Color.BLACK);
        NextScreenCheckBox.setBounds(0, 0 , 350, 30);
        StoryLine.setFont(new Font("Algerian", Font.BOLD, 15));
        StoryLine.setBounds(200, 100, 450, 225);
        StoryLine.setForeground(Color.yellow);
        StoryLine.setText("");
        
    }
    // Return the coordinates of the button at any given moment. 
    public int GetNextScreenButtonX(){ return NextScreenButton.getX(); }
    public int GetNextSecreenButtonY(){ return NextScreenButton.getY();}
    
    // ------------------------------------------------------------------------
    //  DEFINE the intermission screen that is being shown at a given moment. 
    // ------------------------------------------------------------------------
    public void SetIntermission(){ 
        switch (Scene.GetGameScore()) {
            case 0:
                SetScene();
                StoryLine.setText("It is time to Cobber up! Let's go!");
                AddActionListenerToCheckBox(1);

                break;
            case 1:
                SetScene();
                StoryLine.setText("Rock.. Paper.. ROOOLLL COBBS!");
                AddActionListenerToCheckBox(2);
                break;
            case 3:
                SetScene();
                StoryLine.setFont(new Font("Algerian", Font.BOLD, 12));
                StoryLine.setText("IT'S A DISCO PARTY. Find your way to the dance floor.");
                AddActionListenerToCheckBox(4);
                break;
            case 5:
                SetScene();
                StoryLine.setText("5000 is the magic number,see if you can reach it!");
                AddActionListenerToCheckBox(6);
                break;
            case 7:
                SetScene();
                StoryLine.setText("Finally, you survived.");
                NextScreenCheckBox.setVisible(false);
                AddActionListenerToCheckBox(8);
                break;
        }
    }
    // ------------------------------------------------------------------------
    //  ONCE a box is selected, move on to the next scene. 
    // ------------------------------------------------------------------------
    public void AddActionListenerToCheckBox(int value) {
        NextScreenCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent CheckBoxClicked) {
                if(NextScreenCheckBox.isSelected()){ 
                    NextScreenCheckBox.setSelected(false);
                    FirstFrame.dispose();
                GameWin(value); 
            }
            }});
    }
    
    // ------------------------------------------------------------------------
    //  Overload the Scene superclass's method of Game win
    // ------------------------------------------------------------------------
    
    public void GameWin(int val) {
        Scene.SetGameScore(val);
     
    }  
    // ------------------------------------------------------------------------
    //  BEGIN the game
    // ------------------------------------------------------------------------
    @Override
    public void PlayGame() {
        SetIntermission();
       
}
}
