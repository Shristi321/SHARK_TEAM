package cobberupfinal;
/* @author S(H)ARK TANK  */

public class CobberUpFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        RockPaperScissors RockGame= new RockPaperScissors();
        PoppingCob PoppingGame = new PoppingCob(); 
        Intermission intermission = new Intermission();

         for(Scene.GetGameScore(); Scene.GetGameScore()<9; ){
            Board model=new Board();
          switch (Scene.GetGameScore()) {
            case 0: intermission.PlayGame();
                break;
            case 1: intermission.PlayGame();
                break;
            case 2: intermission.FirstFrame.dispose(); RockGame.PlayGame();
                break;
            case 3:  RockGame.myFrame.dispose(); intermission.PlayGame();
                break;
               
            case 4: intermission.FirstFrame.dispose(); PoppingGame.PlayGame();
                break; 
            case 5: PoppingGame.MainFrame.dispose();PoppingGame.SecondaryFrame.dispose(); 
            intermission.PlayGame();
                break; 
            case 6: intermission.FirstFrame.dispose(); model.PlayGame();
                break;
            case 7: model.pacman.dispose(); intermission.PlayGame(); break;
        }
    }
        
    }
}


