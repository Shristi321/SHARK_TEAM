
package cobberupfinal;

/* @author S(H)ARK TANK  RITA */

// ------------------------------------------------------------------------
//  Information to change game, has the game been won? Has the game started?
// ------------------------------------------------------------------------
public interface IScene {
    public void GameWin();
    public void PlayGame(); 
        
}
