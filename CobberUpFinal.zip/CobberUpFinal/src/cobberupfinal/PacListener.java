
package cobberupfinal;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/* @author S(H)ARK TANK SHRISTI */
public class PacListener implements KeyListener{
    // ------------------------------------------------------------------------
    //  CREATES instances of the board and pacman classes
    // ------------------------------------------------------------------------
    Board model;
    PacMan man;
    
    /**
     * Default constructors
     */
    public PacListener(){
        
    }
    
    /**
     * Full Pac man constructor 
     * @param man
     * @param model 
     */
    public PacListener(PacMan man, Board model){
        this.man = man;
        this.model = model;
    }
    
    // ------------------------------------------------------------------------
    //  IF key is pressed, move in said direction 
    // ------------------------------------------------------------------------
    
    @Override
    public void keyPressed(KeyEvent ke) {
        int code = ke.getKeyCode();
        
        switch (code){
            case KeyEvent.VK_LEFT:
                moveLeft(code);
                break;

            case KeyEvent.VK_RIGHT:
                if (model.board[man.pacx + 1][man.pacy] != 1) {
                    man.startangle = 30;
                    man.pacx += 1;
                } break;

            case KeyEvent.VK_UP:
                if(model.board[man.pacx][man.pacy - 1] != 1) {
                    man.startangle = 120;
                    man.pacy -= 1;
                } break;

            case KeyEvent.VK_DOWN:
                if(model.board[man.pacx][man.pacy + 1] != 1) {
                    man.startangle = 300;
                    man.pacy += 1;
                } break;
        }
    }

    public void moveLeft(int ke){
        if(model.board[man.pacx - 1][man.pacy] != 1){
            man.startangle = 210;
            man.pacx -= 1;
        }
    }

    //Override Keylistener impl. 
    @Override
    public void keyReleased(KeyEvent e){
    }

    @Override
    public void keyTyped(KeyEvent arg0){
    }

}
