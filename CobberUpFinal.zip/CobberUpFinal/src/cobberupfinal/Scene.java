
package cobberupfinal;


import javax.swing.JFrame; 

/* @author S(H)ARK TANK  RITA */

public class Scene implements IScene{
    // ------------------------------------------------------------------------
    //  CREATE the main JFrame window to house the game
    // ------------------------------------------------------------------------
    
    public void SetScene(){
        JFrame MainFrame = new JFrame("Cobber Up");
        MainFrame.setSize(900, 600);
        MainFrame.setVisible(true);
        MainFrame.setResizable(false);
        MainFrame.setLocationRelativeTo(null);
        MainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    // ------------------------------------------------------------------------
    //  IF game is won, add the score 
    // ------------------------------------------------------------------------
    @Override
    public void GameWin() {
        SetGameScore(0); 
    }
    
    // ------------------------------------------------------------------------
    //  Getters and setters for the current score. 
    // ------------------------------------------------------------------------
    
    static int GameScore;
    public static void SetGameScore(int val){ GameScore =val; }
    public static int GetGameScore(){ return GameScore; }
    

    // ------------------------------------------------------------------------
    //  BEGIN the game
    // ------------------------------------------------------------------------
    @Override
    public void PlayGame() {

    }
}
