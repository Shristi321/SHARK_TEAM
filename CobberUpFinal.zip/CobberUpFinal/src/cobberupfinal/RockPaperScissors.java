
package cobberupfinal;


import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


/* @author S(H)ARK TANK KINSEY */
public class RockPaperScissors extends Scene{
    
    // ------------------------------------------------------------------------
    //  CREATE the main JFrame window to house the game
    // ------------------------------------------------------------------------
    public static int playerScore = 0;
    public static int GetPlayerScore(){ return playerScore; }
    public static void SetPlayerScore(int val){ playerScore = val; }
    
    //Instance variables for Rock Paper Scissors
    public static final int rock = 0;
    public static final int paper = 1;
    public static final int scissor = 2;
    Random computer = new Random();
    int selection;
    
    // ------------------------------------------------------------------------
    //  CREATE JComponents for Rock Paper Scissors
    // ------------------------------------------------------------------------
    JFrame myFrame = new JFrame("ROCK PAPER SCISSORS");
    JLabel text = new JLabel ("\nWelcome to Rock Paper Scissor");
    
        JLabel winText = new JLabel ("|YOU WIN!|");
        JLabel loseText = new JLabel ("|YOU LOSE...|");
        JLabel tieText = new JLabel ("|YOU TIE|");
        //text for what option the computer you picked
        JLabel computerPickRock = new JLabel (" The computer picked Rock");
        JLabel computerPickPaper = new JLabel (" The computer picked Paper");
        JLabel computerPickScissor = new JLabel (" The computer picked Scissors");
        JButton button1 = new JButton("Rock");
        JButton button2 = new JButton("Paper");
        JButton button3 = new JButton("Scissor");
        JPanel panel = new JPanel();
        
        
        
    // ------------------------------------------------------------------------
   //   Override set scene method from Scene Superclass 
   // ------------------------------------------------------------------------
    @Override
    public void SetScene(){
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setVisible(true);
        
        panel.setSize (500,500);
        myFrame.setSize(500,500);
        
        //sets the buttin size so they are not huge
        button1.setSize(20,20);
        button2.setSize(20,20);
        button3.setSize(20,20);
        
        //adds the button to the panel and the panel to the frame
        panel.add(text);
        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        myFrame.add(panel);
        
        myFrame.pack();
    }
    // ------------------------------------------------------------------------
    //  Game rules, pick a object and play
    // ------------------------------------------------------------------------
    
    // Computer is assigned a random variable. 
    public int ComputerPick()
        {
            Random computer = new Random();
            int computerPick = computer.nextInt(3);
            return computerPick;
        }
    
    // Set the game rules 
    public void GameRules() {
        int selection;
        //Continue to play until payer wins. 
        while (playerScore != 2) {
            
            // Player selects Rock
            if (button1.getModel().isPressed()) {
                int computerPick = ComputerPick();
                selection = 2;
                myFrame.add(panel);
                myFrame.pack();
                
                // Player(Rock) vs. Paper
                if (computerPick == 1) {
                    panel.add(computerPickPaper);
                    panel.add(loseText);
                    myFrame.add(panel);
                    myFrame.pack();

                }

                //Player(Rock) vs Scissors
                if (computerPick == 2) {
                    panel.add(computerPickScissor);
                    panel.add(winText);
                    playerScore++;

                    myFrame.add(panel);
                    myFrame.pack();
                }

                //Player(Rock) vs Rock
                if (computerPick == 0) {
                    panel.add(computerPickRock);
                    panel.add(tieText);
                    myFrame.add(panel);
                    myFrame.pack();

                }
            } 
            //Player chooses paper 
            else if (button2.getModel().isPressed()) {
                int computerPick = ComputerPick();
                selection = 1;
                myFrame.add(panel);
                myFrame.pack();

                //Player(Paper) vs Rock 
                if (computerPick == 0) {
                    panel.add(computerPickRock);
                    panel.add(winText);
                    myFrame.add(panel);
                    playerScore++;

                    myFrame.pack();
                }
                //Player(Paper) vs Paper
                else if (computerPick == 1) {
                    panel.add(computerPickPaper);
                    panel.add(tieText);
                    myFrame.add(panel);
                    myFrame.pack();

                } //Player(Paper) vs Scissors
                else if (computerPick == 2) {
                    panel.add(computerPickScissor);
                    panel.add(loseText);
                    myFrame.add(panel);
                    myFrame.pack();
                }
            } //Player chooses scissors
            else if (button3.getModel().isPressed()) {
                int computerPick = ComputerPick();
                selection = 2;
                myFrame.add(panel);
                myFrame.pack();

                //Player(Scissors) vs Rock 
                if (computerPick == 0) {
                    panel.add(computerPickRock);
                    panel.add(loseText);
                    myFrame.add(panel);
                    myFrame.pack();
                } 
                //Player(Scissors) vs Paper
                else if (computerPick == 1) {
                    panel.add(computerPickPaper);
                    panel.add(winText);
                    playerScore++;
                    myFrame.add(panel);
                    myFrame.pack();
                } 
                //Player(Scissors) vs Scissors
                else if (computerPick == 2) {
                    panel.add(computerPickScissor);
                    panel.add(tieText);
                    myFrame.add(panel);
                    myFrame.pack();

                }
            }
            myFrame.pack();
            if (GetPlayerScore() == 2) {
                GameWin();
                myFrame.pack();
                myFrame.dispose();
                break;

            }

        }
    }

    // ------------------------------------------------------------------------
    //  WHEN game starts, set score to 0
    // ------------------------------------------------------------------------
    @Override
    public void GameWin() {
        Scene.SetGameScore(3);
    }

    // ------------------------------------------------------------------------
    //  BEGIN the rock paper scissors game
    // ------------------------------------------------------------------------
    @Override
    public void PlayGame() {
        ComputerPick();
        SetScene();
        GameRules();

    }

}
