
package cobberupfinal;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


/* @author S(H)ARK TANK  RITA */

public class PoppingCob extends Scene {
    // ------------------------------------------------------------------------
    //  CREATE all JComponents and initialize their text
    // ------------------------------------------------------------------------
    // Main JComponents
    JFrame MainFrame = new JFrame("Popping Cob");
    JButton EventButton = new JButton(""); 
    JRadioButton CheckBox = new JRadioButton();
    JPanel MainPanel = new JPanel(); 
    
    // Main Panel boundries
    JPanel RedPanel1 = new JPanel();
    JPanel RedPanel2 = new JPanel();
    JPanel OrangePanel1 = new JPanel();
    JPanel OrangePanel2 = new JPanel();
    JPanel GreenPanel = new JPanel(); 
    JPanel BluePanel = new JPanel();
    
    // Secondary JComponents
    JFrame SecondaryFrame = new JFrame("Corn, popped");
    JPanel SecondaryPanel = new JPanel();
    JLabel SecondaryPanelText = new JLabel("CHANGE");
   
    // ------------------------------------------------------------------------
    //  Set the scene for the game: Set sizes, layouts, and visibility
    // ------------------------------------------------------------------------
    @Override
    public void SetScene(){
        // Create the initial JFrame
        MainFrame.add(MainPanel);
        MainFrame.setSize(900, 600);
        MainFrame.setVisible(true);
        MainFrame.setResizable(false);
        MainFrame.setLayout(null);
        MainFrame.setLocationRelativeTo(null);
        MainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MainPanel.setSize(200,200);
        MainPanel.setLayout(null);
    }
  
    //  Add panel boundries for the JFrame (recolor to show boundries). 
    
    public void AddBoundries(){
        // Red panels
        MainFrame.add(RedPanel1);
        MainFrame.add(RedPanel2);
        RedPanel1.setBounds(200, 0, 100, 300);
        RedPanel2.setBounds(0, 200, 200, 100);
        
        //Orange Panels
        MainFrame.add(OrangePanel1);
        MainFrame.add(OrangePanel2);
        OrangePanel1.setBounds(300, 0, 150, 400);
        OrangePanel2.setBounds(0, 300, 300, 100);
        
        //Green Panel
        MainFrame.add(GreenPanel);
        GreenPanel.setBounds(0,400,900,200);
        
        //Blue Panel 
        MainFrame.add(BluePanel); 
        BluePanel.setBounds(450,0,445,400);
    }
    
    // ------------------------------------------------------------------------
    //  Add button, set trancparacy, get coordinates, add action listener
    // ------------------------------------------------------------------------
    
    // Add buttons to the main panel, set trancparacy
    public void AddButtons() {
        EventButton.setBounds(100, 100, 10, 10);
        EventButton.setOpaque(false);
        EventButton.setContentAreaFilled(false);
        EventButton.setBorderPainted(false);
        MainPanel.add(EventButton);
    }
    
    // Return the buttons' cordinates at any given moment.
    public int GetEventButtonX(){ return EventButton.getX(); }
    public int GetEventButtonY(){ return EventButton.getY();}
    
    // Add an action listener to button. Action: If mouse hovers over, make checkbox visible.  
    public void AddActionListenerToButton(){
        EventButton.addMouseListener(new MouseAdapter(){
        
        @Override 
        public void mouseEntered(MouseEvent e){
            int MouseX = e.getX();
            int MouseY = e.getY();
            int ButtonX = GetEventButtonX() + 1;
            int ButtonY = GetEventButtonY() + 1;
            
            while(CheckBox.isSelected() == false){
                if(MouseX < ButtonX && MouseY < ButtonY){
                CheckBox.setVisible(true);
                GameWin();
                break;}}}});     
    }
    
    // ------------------------------------------------------------------------
    //  Set the scene for the secondary JFrame
    // ------------------------------------------------------------------------
    
    // Set scene method for second JFrame
    public void SetSecondayScene(){
       SecondaryFrame.setBounds(0, 0, 200, 200);
       SecondaryFrame.add(SecondaryPanel);
       SecondaryFrame.setVisible(true);
       SecondaryFrame.setResizable(false); 
       SecondaryPanel.add(SecondaryPanelText);   
    }
    // Change the colors of all panels on screen 
    public void ChangeAllColors(int Red, int Green, int Blue){
        Color  color = new Color(Red, Green, Blue);
        MainFrame.setBackground(color);
        MainPanel.setBackground(color);
        SecondaryPanel.setBackground(color);
        RedPanel1.setBackground(color);
        RedPanel2.setBackground(color);
        OrangePanel1.setBackground(color);
        OrangePanel2.setBackground(color);
        GreenPanel.setBackground(color);
        BluePanel.setBackground(color); 
    }
    // Depending on the placement of the mouse, 
    //  change the color of the panel and change the text.
    public void AddActionListenerToPanels(){ 
        MainPanel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){ChangeAllColors(250,0,2);
            SecondaryPanelText.setText("HOOOOOOT"); } 
        });
        
        RedPanel1.addMouseListener(new MouseAdapter(){
            @Override 
            public void mouseEntered(MouseEvent e){ ChangeAllColors(216,0,39);
            SecondaryPanelText.setText("Hot-ish");
            }
            
        });
        RedPanel2.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){ ChangeAllColors(161,1,93); 
            SecondaryPanelText.setText("Hot-ish");
            }
        });   
        OrangePanel1.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){ ChangeAllColors(99, 0, 158); 
            SecondaryPanelText.setText("Warmer");
            }
        });
        OrangePanel2.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){ ChangeAllColors(42, 0, 213); 
            SecondaryPanelText.setText("Warmer");
            }
        });   
        GreenPanel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){ ChangeAllColors(3,2,252); 
            SecondaryPanelText.setText("Warm");}
        });
        BluePanel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){ ChangeAllColors(255, 255, 255); 
            SecondaryPanelText.setText("ICY");}
        });   
            
    }
    
    // ------------------------------------------------------------------------
    //  IF the game is won, move on to the next game.
    // ------------------------------------------------------------------------
    @Override
    public void GameWin() {
        Scene.SetGameScore(5);
        MainFrame.dispose();
        SecondaryFrame.dispose();
    }
    // ------------------------------------------------------------------------
    //  Define the neccesary components to this game. 
    // ------------------------------------------------------------------------
    public void GameRules(){
        this.SetSecondayScene();
        this.SetScene();
        this.AddBoundries();
        this.AddButtons();
        this.AddActionListenerToButton();
        this.AddActionListenerToPanels();
    }
    // ------------------------------------------------------------------------
    //  A defined method in the Scene interface, passes GameRules.
    // ------------------------------------------------------------------------
    @Override 
    public void PlayGame() {
        GameRules();
    }
}

